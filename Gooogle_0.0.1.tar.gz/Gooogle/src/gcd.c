#include <math.h>
#include <string.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <R.h>
#include <R_ext/Applic.h>
// #include "gplus_init.c"

double norm(double *x, int p);
double S(double, double);
double F(double, double, double);
double Fs(double, double, double);
double gLoss(double *r, int n);
double dotproduct(double *u, double *v, int);

SEXP groupCoordinateDescent(
    SEXP groupMatOrth_, 
    SEXP lambda_,
    SEXP penaltyFactors_,
    SEXP initialB_,
    SEXP epsilon_,
    SEXP groupStartIndices_,
    SEXP pseudoY_,
    SEXP gamma_,
    SEXP penalty_,
    SEXP maxIterations_) {

    // get lengths
    // number of observations
    int n = length(pseudoY_);
    // number of lambda values to try
    int L = length(lambda_);
    // number of groups
    int J = length(groupStartIndices_) - 1;
    // number of coefficients needed (variables including intercepts)
    int p = length(groupMatOrth_)/n;

    // create pointers for translation from R to C
    double *X = REAL(groupMatOrth_);
    double *lambda = REAL(lambda_);
    double *penalty_factors = REAL(penaltyFactors_);
    double *start = REAL(initialB_);
    double eps = REAL(epsilon_)[0];
    int *markers = INTEGER(groupStartIndices_);
    double *Y = REAL(pseudoY_);
    double gamma = REAL(gamma_)[0];
    const char *penalty = CHAR(STRING_ELT(penalty_, 0));
    int max_iterations = INTEGER(maxIterations_)[0];
    
    // initialise the return result of all coefficient solutions
    SEXP coefficients;
    PROTECT(coefficients = allocVector(REALSXP, L*p));

    for (int j=0; j<(L*p); j++) REAL(coefficients)[j] = 0;
    double *b = REAL(coefficients);

    // group coordinate descent

    for (int j = 0; j <= J; j++) {
        markers[j] -= 1;
    }

    double res[n];
    for (int j = 0; j < n; j++) {
        double row[p];
        for (int k = 0; k < p; k++) {
            row[k] = X[j + k * n];
        }
        res[j] = Y[j] - dotproduct(row, b, p);
    }
    double rss = gLoss(res, n);
    double sdy = sqrt(rss/n);
    
    // loop over the lambdas
    for(int i = 0; i < L; i++) {
        // create the vector of penalty factors by multiplying lambda by penalty factors
        // initialise gcd values
        double pf[p];
        double b[p];
        for (int j = 0; j < p; j++) {
            pf[j] = lambda[i] * penalty_factors[j];
            b[j] = start[j];
        }

        double r[n];
        for (int i = 0; i < n; i++) {
            r[i] = res[i];
        }
        
        // gcd steps
        for (int j = 0; j < max_iterations; j++) {
            int max_change = 0;
            double l0 = pf[0];
            for (int k = markers[0]; k < markers[1]; k++) {
                double b1 = b[k];
                double col[n];
                for (int q = 0; q < n; q++) {
                    col[q] = X[k * n + q];
                }
                double z = (1 / n) * dotproduct(col, r, n) + b1;
                double b2  = 0;
                if (strcmp(penalty, "grLasso")==0) b2 = S(z, l0);
                if (strcmp(penalty, "grMCP")==0) b2 = F(z, l0, gamma);
                if (strcmp(penalty, "grSCAD")==0) b2 = Fs(z, l0, gamma);
                double bdiff = b2 - b1;
                for (int q = 0; q < n; q++) {
                    r[q] = r[q] - col[q] * bdiff;
                }
                if (fabs(bdiff) > max_change) {
                    max_change = fabs(bdiff);
                }
                b[k] = b2;
            }
            for (int k = 1; k <= J; k++) {
                double l1 = pf[k];
                int group_size = markers[k+1] - markers[k];
                double b1[group_size];
                double Mr[group_size];
                for (int q = markers[k]; q < markers[k+1]; q++) {
                    b1[q - markers[k]] = b[q];
                    double col[n];
                    for (int t = 0; t < n; t++) {
                        col[t] = X[q * n + t];
                    }
                    Mr[q - markers[k]] = dotproduct(col, r, n);
                }
                double z[group_size];
                for (int q = 0; q < group_size; q++) {
                    z[q] = 1/n * Mr[q] + b1[q];
                }
                double z_norm = norm(z, group_size);
                double thresh = 0;
                if (strcmp(penalty, "grLasso")==0) thresh = S(z_norm, l1);
                if (strcmp(penalty, "grMCP")==0) thresh = F(z_norm, l1, gamma);
                if (strcmp(penalty, "grSCAD")==0) thresh = Fs(z_norm, l1, gamma);
                double b2[group_size];
                double bdiff[group_size];
                for (int q = 0; q < group_size; q++) {
                    // what i f z_norm is zero?
                    if (z_norm != 0) {
                        b2[q] = thresh*b1[q]/z_norm;
                        bdiff[q] = b1[q]*(thresh - 1)/z_norm;
                    } else {
                        b2[q] = 0;
                        bdiff[q] = 0;
                    }
                }
                double Mb[n];
                for (int q = 0; q < n; q++) {
                    double rowsect[group_size];
                    for (int t = markers[k]; t < markers[k+1]; t++) {
                        rowsect[t - markers[k]] = X[n * t + q];
                    }
                    Mb[q] = dotproduct(rowsect, bdiff, group_size);
                }
                for (int q = 0; q < n; q++) {
                    r[q] = r[q] - Mb[q];
                }

                for (int q = 0; q < group_size; q++) {
                    if (fabs(bdiff[q]) > max_change) {
                        max_change = fabs(bdiff[q]);
                    }
                }
                for (int q = markers[k]; q < markers[k+1]; q++) {
                    b[q] = b2[q];
                }
            }
            if (max_change < eps * sdy) {
                break;
            }
        }
        // append the coefficients b for each lambda to the array of coefficients
        for (int j = i * p; j < (i + 1) * p; i++) {
            REAL(coefficients)[j] = b[j - (i * p)];
        }
    }
    return(coefficients);
}
