#include <math.h>
#include <string.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>
#include <R.h>
#include <R_ext/Applic.h>

double crossprod(double *x, double *y, int n, int j);
double norm(double *x, int p);
double S(double, double);
double F(double, double, double);
double Fs(double, double, double);
double gLoss(double *r, int n);

// Group descent update
void gd_gaussian(double *b, double *x, double *r, int g, int *K1, int *K,
                 int n, int l, int p, const char *penalty, double lambda,
                 double gamma, double *a, double *maxChange) {
  // Calculate z
  double *z = R_Calloc(K[g], double);
  for (int j=K1[g]; j<K1[g+1]; j++) z[j-K1[g]] = crossprod(x, r, n, j)/n + a[j];
  double z_norm = norm(z, K[g]);
  
  // Update b
  double len;
  if (strcmp(penalty, "grLasso")==0) len = S(z_norm, lambda);
  if (strcmp(penalty, "grMCP")==0) len = F(z_norm, lambda, gamma);
  if (strcmp(penalty, "grSCAD")==0) len = Fs(z_norm, lambda, gamma);
  if (len != 0 || a[K1[g]] != 0) {
    // If necessary, update beta and r
    for (int j=K1[g]; j<K1[g+1]; j++) {
      b[l*p+j] = len * z[j-K1[g]] / z_norm;
      double shift = b[l*p+j]-a[j];
      if (fabs(shift) > maxChange[0]) maxChange[0] = fabs(shift);
      for (int i=0; i<n; i++) r[i] -= x[n*j+i] * shift;
    }
  }
  free(z);
}


SEXP gdfit_gaussian(SEXP X_, SEXP y_, SEXP penalty_, SEXP K1_, SEXP K0_, 
                    SEXP lambda, SEXP lam_max_, SEXP alpha_, SEXP eps_, 
                    SEXP max_iter_, SEXP gamma_, SEXP group_multiplier, 
                    SEXP gmax_) {

  // Lengths/dimensions
  int n = length(y_);
  int L = length(lambda);
  int J = length(K1_) - 1;
  int p = length(X_)/n;
  
  // Pointers
  double *X = REAL(X_);
  double *y = REAL(y_);
  const char *penalty = CHAR(STRING_ELT(penalty_, 0));
  int *K1 = INTEGER(K1_);
  int K0 = INTEGER(K0_)[0];
  double *lam = REAL(lambda);
  double lam_max = REAL(lam_max_)[0];
  double alpha = REAL(alpha_)[0];
  double eps = REAL(eps_)[0];
  int max_iter = INTEGER(max_iter_)[0];
  int tot_iter = 0;
  double gamma = REAL(gamma_)[0];
  double *m = REAL(group_multiplier);
  int gmax = INTEGER(gmax_)[0];
  
  // Outcome
  SEXP coeff
  PROTECT(coeff = allocVector(REALSXP, L*p));
  for (int j=0; j<(L*p); j++) REAL(coeff)[j] = 0;
  double *b = REAL(coeff);

  // Intermediate quantities
  double *r = R_Calloc(n, double);
  for (int i=0; i<n; i++) r[i] = y[i];
  double *a = R_Calloc(p, double);
  for (int j=0; j<p; j++) a[j] = 0;
  int lstart = 0, ng, nv;
  double shift, l1, maxChange;
  
  // If lam[0]=lam_max, skip lam[0] -- closed form sol'n available
  double rss = gLoss(r, n);
  double sdy = sqrt(rss/n);

  // Path
  for (int l=lstart; l<L; l++) {
    R_CheckUserInterrupt();
    if (l != 0) {
      for (int j=0; j<p; j++) a[j] = b[(l-1)*p+j];

      // Check dfmax, gmax
      ng = 0;
      nv = 0;
      for (int g=0; g<J; g++) {
        if (a[K1[g]] != 0) {
          ng++;
          nv = nv + (K1[g+1]-K1[g]);
        }
      }
      if (ng > gmax || tot_iter == max_iter) {
        for (int ll=l; ll<L; ll++) INTEGER(iter)[ll] = NA_INTEGER;
        break;
      }
    }
    
    while (tot_iter < max_iter) {
      while (tot_iter < max_iter) {
        while (tot_iter < max_iter) {
          INTEGER(iter)[l]++;
          tot_iter++;
          maxChange = 0;
          
          // Update unpenalized covariates
          for (int j=0; j<K0; j++) {
            shift = crossprod(X, r, n, j)/n;
            if (fabs(shift) > maxChange) maxChange = fabs(shift);
            b[l*p+j] = shift + a[j];
            for (int i=0; i<n; i++) r[i] -= shift * X[n*j+i];
          }
          
          // Update penalized groups
          for (int g=0; g<J; g++) {
            l1 = lam[l] * m[g];
            gd_gaussian(b, X, r, g, K1, K, n, l, p, penalty, l1, gamma, a, &maxChange);
          }

          // Check convergence
          for (int j=0; j<p; j++) a[j] = b[l*p+j];
          if (maxChange <= eps*sdy) break;
        }
      }
    }
  }
  free(a);
  free(r);
  // SET_VECTOR_ELT(res, 0, coeff);
  UNPROTECT(3);
  return(coeff);
}
